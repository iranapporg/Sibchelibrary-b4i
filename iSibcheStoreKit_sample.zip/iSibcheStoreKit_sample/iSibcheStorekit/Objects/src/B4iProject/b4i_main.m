
#import "b4i_main.h"


@implementation b4i_main 


+ (instancetype)new {
    static b4i_main* shared = nil;
    if (shared == nil) {
        shared = [self alloc];
        shared.bi = [[B4I alloc] init:shared];
        shared.__c = [B4ICommon new];
    }
    return shared;
}

- (NSString*)  _application_background{
 //BA.debugLineNum = 39;BA.debugLine="Private Sub Application_Background";
 //BA.debugLineNum = 41;BA.debugLine="End Sub";
return @"";
}
- (BOOL)  _application_openurl:(NSString*) _url :(NSObject*) _data :(NSString*) _sourceapplication{
 //BA.debugLineNum = 59;BA.debugLine="Sub Application_OpenUrl (Url As String, Data As Ob";
 //BA.debugLineNum = 60;BA.debugLine="ssk.OpenURL(Url,Data,SourceApplication)";
[self->__ssk OpenURL:_url :_data :_sourceapplication];
 //BA.debugLineNum = 61;BA.debugLine="Return True";
if (true) return true;
 //BA.debugLineNum = 62;BA.debugLine="End Sub";
return false;
}
- (NSString*)  _application_start:(B4INavigationControllerWrapper*) _nav{
[self initializeStaticModules];
 //BA.debugLineNum = 23;BA.debugLine="Private Sub Application_Start (Nav As NavigationCo";
 //BA.debugLineNum = 24;BA.debugLine="SetDebugAutoFlushLogs(True) 'Uncomment if program";
[self->___c SetDebugAutoFlushLogs:true];
 //BA.debugLineNum = 25;BA.debugLine="NavControl = Nav";
self->__navcontrol = _nav;
 //BA.debugLineNum = 26;BA.debugLine="Page1.Initialize(\"Page1\")";
[self->__page1 Initialize:self.bi :@"Page1"];
 //BA.debugLineNum = 27;BA.debugLine="Page1.Title = \"Page 1\"";
[self->__page1 setTitle:@"Page 1"];
 //BA.debugLineNum = 28;BA.debugLine="Page1.RootPanel.Color = Colors.White";
[[self->__page1 RootPanel] setColor:[[self->___c Colors] White]];
 //BA.debugLineNum = 29;BA.debugLine="NavControl.ShowPage(Page1)";
[self->__navcontrol ShowPage:(UIViewController*)((self->__page1).object)];
 //BA.debugLineNum = 31;BA.debugLine="ssk.Initialize(\"ssk\",\"jvLVnOYRmqWk3aAKVQ3dD1NgyPQ";
[self->__ssk Initialize:self.bi :@"ssk" :@"jvLVnOYRmqWk3aAKVQ3dD1NgyPQlK0" :@"myuniquescheme"];
 //BA.debugLineNum = 32;BA.debugLine="ssk.FetchAllInAppPurchasePackage";
[self->__ssk FetchAllInAppPurchasePackage];
 //BA.debugLineNum = 33;BA.debugLine="End Sub";
return @"";
}
- (NSString*)  _page1_click{
 //BA.debugLineNum = 43;BA.debugLine="Sub Page1_Click";
 //BA.debugLineNum = 44;BA.debugLine="ssk.PurchasePackage(\"test\")";
[self->__ssk PurchasePackage:@"test"];
 //BA.debugLineNum = 45;BA.debugLine="End Sub";
return @"";
}
- (NSString*)  _page1_resize:(int) _width :(int) _height{
 //BA.debugLineNum = 35;BA.debugLine="Private Sub Page1_Resize(Width As Int, Height As I";
 //BA.debugLineNum = 37;BA.debugLine="End Sub";
return @"";
}

- (void)initializeStaticModules {
    [[b4i_main new]initializeModule];

}
- (NSString*)  _process_globals{
 //BA.debugLineNum = 14;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 17;BA.debugLine="Public App As Application";
self->__app = [B4IApplicationWrapper new];
 //BA.debugLineNum = 18;BA.debugLine="Public NavControl As NavigationController";
self->__navcontrol = [B4INavigationControllerWrapper new];
 //BA.debugLineNum = 19;BA.debugLine="Private Page1 As Page";
self->__page1 = [B4IPage new];
 //BA.debugLineNum = 20;BA.debugLine="Private ssk As SibcheStoreKit";
self->__ssk = [iSibcheStoreKit new];
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
return @"";
}
- (NSString*)  _ssk_allpackagelistarrived:(B4IList*) _packagelist{
B4ISibchePackage* _package = nil;
 //BA.debugLineNum = 52;BA.debugLine="Sub ssk_AllPackageListArrived (PackageList As List";
 //BA.debugLineNum = 53;BA.debugLine="For Each package As SibchePackage In PackageList";
_package = [B4ISibchePackage new];
{
const id<B4IIterable> group1 = _packagelist;
const int groupLen1 = group1.Size
;int index1 = 0;
;
for (; index1 < groupLen1;index1++){
_package.object = (SibchePackage*)([group1 Get:index1]);
 //BA.debugLineNum = 54;BA.debugLine="Log(package.name)";
[self->___c LogImpl:@"3393218" :[_package name] :0];
 }
};
 //BA.debugLineNum = 56;BA.debugLine="End Sub";
return @"";
}
- (NSString*)  _ssk_packagepurchased:(B4ISibchePurchasePackage*) _package{
 //BA.debugLineNum = 48;BA.debugLine="Sub ssk_PackagePurchased (Package As SibchePurchas";
 //BA.debugLineNum = 49;BA.debugLine="Msgbox(Package.code,\"\")";
[self->___c Msgbox:[_package code] :@""];
 //BA.debugLineNum = 50;BA.debugLine="End Sub";
return @"";
}
@end
