#import "iCore.h"
#import "iSibcheStoreKit.h"
@interface b4i_main : B4IStaticModule
{
@public B4IApplicationWrapper* __app;
@public B4INavigationControllerWrapper* __navcontrol;
@public B4IPage* __page1;
@public iSibcheStoreKit* __ssk;

}- (NSString*)  _application_background;
- (BOOL)  _application_openurl:(NSString*) _url :(NSObject*) _data :(NSString*) _sourceapplication;
- (NSString*)  _application_start:(B4INavigationControllerWrapper*) _nav;
- (NSString*)  _page1_click;
- (NSString*)  _page1_resize:(int) _width :(int) _height;
- (NSString*)  _process_globals;
@property (nonatomic)B4IApplicationWrapper* _app;
@property (nonatomic)B4INavigationControllerWrapper* _navcontrol;
@property (nonatomic)B4IPage* _page1;
@property (nonatomic)iSibcheStoreKit* _ssk;
- (NSString*)  _ssk_allpackagelistarrived:(B4IList*) _packagelist;
- (NSString*)  _ssk_packagepurchased:(B4ISibchePurchasePackage*) _package;
@end
